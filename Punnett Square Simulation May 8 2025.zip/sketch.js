let dadGeneDom = "H"
let dadGeneRec = "h"
let momGeneDom = "h"
let momGeneRec = "h"
let b1
let b2
let b3
let b4
let chance
let numHD =0
let e
function setup() {
  if(windowWidth>windowHeight){
    e = windowHeight
  }else(e=windowWidth)
  
  createCanvas(e,e)
  
}

function draw() {
  //making it dominant
  if(momGeneRec == "H"){
    momGeneDom = "H"
  }
  if(dadGeneRec == "H"){
    dadGeneDom = "H"
  }
  
  background(100, 125, 155)
  fill(305, 255, 255)
  //top left
  rect((125/400)*e,(75/400)*e,(125/400)*e,(125/400)*e)
  //top right
  rect((275/400)*e,(75/400)*e, (125/400)*e, (125/400)*e)
  //bottom left
  rect((125/400)*e, (225/400)*e, (125/400)*e, (125/400)*e)
  //bottom right
  rect((275/400)*e, (225/400)*e, (125/400)*e, (125/400)*e)
  textSize((25/400)*e)
  text("Dad:", (240/400)*e, (25/400)*e)
  text("Mom:", (5/400)*e, (125/400)*e)
  textSize((10/400)*e)
  text("Dominant Allele: ", (100/400)*e, (70/400)*e)
  text("Dominant Allele: ", (10/400)*e, (150/400)*e)
  text("Recessive Allele: ", (250/400)*e, (70/400)*e)
  text("Recessive Allele: ", (10/400)*e, (300/400)*e)
  textSize((25/400)*e)
  text(dadGeneDom, (175/400)*e, (70/400)*e)
  text(dadGeneRec, (335/400)*e, (70/400)*e)
  text(momGeneDom, (100/400)*e, (150/400)*e)
  text(momGeneRec, (100/400)*e, (300/400)*e)
  
  //setting b1
  if(momGeneDom == "h"){
  b1= dadGeneDom +  momGeneDom
  } else(b1=momGeneDom+dadGeneDom)
  fill(0)
  text(b1,(175/400)*e, (150/400)*e)
  
  //setting b3
   if(momGeneRec == "h"){
  b3= dadGeneDom +  momGeneRec
  } else(b3=momGeneRec+dadGeneDom)
  
  //setting b2 order
   if(momGeneDom == "h"){
  b2= dadGeneRec + momGeneDom
  } else(b2=momGeneDom+dadGeneRec)
  
  //setting b4 order
   if(momGeneRec == "h"){
  b4= dadGeneRec +  momGeneRec
  } else(b4=momGeneRec+dadGeneRec)
  
  //displaying phenotypes
  text(b1,(175/400)*e, (150/400)*e)
  text(b2, (325/400)*e, (150/400)*e)
  text(b3, (175/400)*e, (300/400)*e)
  text(b4, (325/400)*e, (300/400)*e)
  
  //percentages
  if(b1 == "Hh"|| b1=="HH"){
    numHD+=1
  }
  if(b2=="Hh"|| b2 == "HH"){
    numHD+=1
  }
  if(b3=="Hh"|| b3 == "HH"){
    numHD+=1
  }
  if(b4=="Hh"|| b4 == "HH"){
    numHD+=1
  }
  chance= (numHD/4)*100
  textSize((15/400)*e)
  text("Chance of offspring inheiriting Huntington's disease: "+ chance +"%", (10/400)*e, (375/400)*e)
  numHD = 0
  
}
  function mouseClicked(){
    print(mouseX+", "+mouseY)
    if(mouseX < (125/400)*e && mouseX > (90/400)*e && mouseY > (120/400)*e && mouseY < (160/400)*e){
      if(momGeneDom=="h"){
        momGeneDom = "H"
      }else(momGeneDom = "h")
    }
    if(mouseX < (116/400)*e && mouseX > (95/400)*e && mouseY > (279/400)*e && mouseY < (305/400)*e){
      if(momGeneRec=="h"){
        momGeneRec = "H"
      }else(momGeneRec = "h")
    }
    if(mouseX < (199/400)*e && mouseX > (168/400)*e && mouseY > (45/400)*e && mouseY < (71/400)*e){
      if(dadGeneDom=="h"){
        dadGeneDom = "H"
      }else(dadGeneDom = "h")
    }
    if(mouseX < (356/400)*e && mouseX > (325/400)*e && mouseY > (41/400)*e && mouseY < (72/400)*e){
      if(dadGeneRec=="h"){
        dadGeneRec = "H"
      }else(dadGeneRec = "h")
    }
}